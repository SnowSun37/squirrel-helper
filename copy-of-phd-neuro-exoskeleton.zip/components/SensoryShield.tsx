// Feature removed (V17.6)
export const SensoryShield = () => null;