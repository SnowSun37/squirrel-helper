import React, { useState, useEffect } from 'react';

// 🎭 深度扩充诗池：浪漫、哲学、冷峻的社会人心论 (120条)
const POETRY_DATABASE = [
    "我曾在那高山之上，听那风儿诉说往事。",
    "万物皆有裂痕，那是光照进来的地方。",
    "如果你在下午四点来，从三点开始，我就感到快乐。",
    "愿你生命中有足够的云翳，来造成一个美丽的黄昏。",
    "星星在静寂中燃烧，像是梦中未熄的灯火。",
    "我来到这世上，是为了看太阳。",
    "我们就这样走着，不去问路在哪里。",
    "你是那在暮色中，独自盛开的蓝色瞬间。",
    "月亮照耀着，像是大地上的一场大雪。",
    "在宇宙的某个角落，有一朵花只为你一个人盛开。",
    "别去追寻答案，答案就在此时此刻的宁静里。",
    "草在结它的种子，风在摇它的叶子，我们站着，不说话。",
    "在这个世界上，我们只是彼此的一场梦境。",
    "所有的晨曦都带着你的影子，所有的星光都藏着你的呼吸。",
    "孤独是一座花园，里面盛开着清醒的玫瑰。",
    "我想要和你一起生活在某个小镇，共享无尽的黄昏。",
    "去爱吧，就像从未受过伤一样。",
    "每一个瞬间都是一种创造，每一阵风都是一次重逢。",
    "我们被赋予了遗忘，好让未来能够发生。",
    "在大雪纷飞的日子里，我心里依然有一个不可战胜的夏天。",
    "并没有什么可以补偿这种损失，只有这种损失本身。",
    "这就是我的灵魂：它是一个深不可测的、带有蓝色的容器。",
    "当你在这痛苦的世上行走，要像一个已经获救的人。",
    "所有的努力，最终都是为了让自己更自由。",
    "我活在我的生命中，处于不断扩大的圆圈里。",
    "在那静谧的树林里，我捡起了一句未说完的诗。",
    "哪怕生活在阴沟里，依然有人仰望星空。",
    "不要由于你的不眠，而对星空感到遗憾。",
    "如果你愿意，我们可以一起去山顶看最后一场雪。",
    "去向自然求教，它会教你如何优雅地老去。",
    "我并不爱这个世界，但我也不恨它，我只是存在。",
    "每个人都是一座孤岛，但在深处，我们根茎相连。",
    "有些真相，只能在沉默中被听见。",
    "生活就是不断地在废墟上建立新的神庙。",
    "我们相爱，像鸟儿爱着黎明，像松果爱着深秋。",
    "在这里，一切都慢了下来，包括那些沉重的思考。",
    "哪怕只有一秒钟的清醒，也胜过一辈子的沉睡。",
    "去追寻那片丢失的云，它藏着你所有的梦境。",
    "别问我路在哪里，路就在你的脚下蔓延。",
    "在每一个呼吸间，感受生命那博大而沉静的力量。",
    "即便世界破碎，我们依然可以在文字里缝合星光。",
    "生命是一个漫长的下午，我只想和你虚度光阴。",
    "我的灵魂里有太多的蓝色，像是深夜未退的潮汐。",
    "做一个内心丰盈的人，不随波逐流。",
    "所有的离别都是为了下一次，在更高处的重逢。",
    "心里的那座森林，永远不需要路标。",
    "在最深的秋色里，寻找一抹不凋零的蓝。",
    "不要走得太快，让灵魂跟上你的脚步。",
    "你是大海里唯一的岛屿，我是唯一的航行者。",
    "世界虽嘈杂，但你是我心里的那阵微风。",
    "我们不再年轻，但这并不妨碍我们继续做梦。",
    "在孤寂的深夜，我与宇宙进行了一次无声的对话。",
    "时间会流逝，但此刻的宁静是永恒的。",
    "如果你问我远方是什么，我会告诉你它是你心里的光。",
    "去做你该做的，哪怕全世界都在反对你。",
    "在每一个清晨，重新发现世界的美丽与哀愁。",
    "不要害怕未知，那是未来写给你的第一行诗。",
    "你是那颗恒星，无论宇宙如何变迁，始终照亮我的航程。",
    "在这个荒诞的世界里，保持清醒是唯一的反抗。",
    "去爱吧，直到生命化为尘埃。",
    "我不认识你，但我曾在梦里见过你的灵魂。",
    "所有的美好，都值得我们耐心等待。",
    "在最深的痛苦中，往往孕育着最坚韧的力量。",
    "哪怕世界末日明天就来，我今天依然要种下我的苹果树。",
    "去追逐风吧，它会带你去你想去的地方。",
    "在这个瞬息万变的时代，守住内心的平静最难。",
    "我们终将老去，但诗歌永远年轻。",
    "如果你觉得累了，就停下来看看这片星空。",
    "在每一个瞬间，我们都在重新定义自己。",
    "去爱那个不完美的自己，那是你最真实的样子。",
    "哪怕前路漫长，只要出发，总能到达。",
    "生活不只是眼前的学业，还有心里的那片远方。",
    "在这个寂静的夜晚，让文字治愈你所有的不安。",
    "我们都是追梦人，只是梦的颜色各不相同。",
    "去向往常一样生活，去向往常一样热爱。",
    "哪怕只有微弱的光，也能穿透最深的黑暗。",
    "在岁月的流逝中，留住那份最初的纯真。",
    "我们相遇，本就是这世界上最美丽的巧合。",
    "去感受风的呼吸，去聆听大地的脉动。",
    "在这个纷繁复杂的世界里，做一个简单的人。",
    "生活给你的每一份磨难，都是一种变相的成全。",
    "哪怕无人喝彩，也要坚持走完自己的路。",
    "在每一个转角，都可能遇到那个全新的自己。",
    "去热爱这生命中的每一个瞬间，无论好坏。",
    "哪怕世界再冷漠，也不要弄丢心里的那份温柔。",
    "我们都在寻找归宿，其实归宿就在我们的心里。",
    "在每一个日出，重新开启对这世界的热爱。",
    "不要被现实磨平了棱角，那是你最宝贵的勋章。",
    "去追寻那个真实的梦，哪怕它看起来遥不可及。",
    "在这个忙碌的时代，给自己留一点发呆的时间。",
    "生活不只是为了活着，更是为了感受生命的美好。",
    "哪怕路途崎岖，只要心中有光，便无所畏惧。",
    "在每一个平凡的日子里，活出不平凡的姿采。",
    "去热爱那些微小而确定的幸福，它们才是生活的真谛。",
    "哪怕再卑微，也要有属于自己的那片星空。",
    "在岁月的打磨下，让生命绽放出最耀眼的光芒。",
    "我们终将独自上路，但文字是永远的伴侣。",
    "去追求那些让你心动的事物，不负韶华。",
    "在这个快节奏的社会，慢下来也是一种勇气。",
    "哪怕世界再荒芜，也要在心里种下一片森林。",
    "在每一个瞬间，都请记得对自己温柔以待。",
    "生活总是充满变数，但我们的初心永远不变。",
    "哪怕是一个人的旅程，也要走得精彩纷呈。",
    "在每一个清晨，对着镜子里的自己微笑。",
    "去感恩生命中遇到的每一个人，每一件事。",
    "哪怕前路迷茫，只要脚踏实地，总能看清方向。",
    "在这个喧嚣的城市，找寻属于自己的一方净土。",
    "生活就是一场修行，我们要在这过程中成就更好的自己。",
    "哪怕只有一点点进步，也值得我们为自己鼓掌。",
    "在每一个黄昏，感受那份独有的宁静与祥和。",
    "去拥抱这变幻莫测的生命，去热爱这精彩万分的世界。",
    "在这个充满了不确定的时代，唯有爱与文字是永恒的。",
    "哪怕身处逆境，也要保持那份对生活的热情。",
    "在岁月的洗礼中，让灵魂变得更加纯净而深邃。",
    "我们终将告别过去，迎接那个未知的未来。",
    "去创造属于自己的传奇，无论大小，无论成败。",
    "在这个充满希望的清晨，开启一段全新的旅程。",
    "生活其实很简单，只要我们用心去感受，去发现。",
    "哪怕只有一线希望，也要倾尽全力去争取。",
    "在每一个夜晚，枕着这些温柔的文字入眠。"
];

export const KingSquirrelPoet: React.FC = () => {
  const [verse, setVerse] = useState("");
  const [isAnimating, setIsAnimating] = useState(false);

  // Helper: Get Atlanta Time Date String
  const getAtlDate = () => {
    return new Intl.DateTimeFormat('en-US', {
        timeZone: 'America/New_York', 
        dateStyle: 'short'
    }).format(new Date());
  };

  const refreshVerse = (force = false) => {
    if (force) {
        setIsAnimating(true);
        if (navigator.vibrate) navigator.vibrate(20);
    }
    
    // Animation delay
    setTimeout(() => {
        let newVerse;
        do {
            newVerse = POETRY_DATABASE[Math.floor(Math.random() * POETRY_DATABASE.length)];
        } while (newVerse === verse && POETRY_DATABASE.length > 1);
        
        setVerse(newVerse);
        setIsAnimating(false);
    }, force ? 300 : 0);
  };

  // Init & Daily Sync
  useEffect(() => {
    const today = getAtlDate();
    const lastDate = localStorage.getItem('sq_v24_date');
    
    if (lastDate !== today) {
        // New day in Atlanta: Refresh
        refreshVerse(false);
        localStorage.setItem('sq_v24_date', today);
    } else {
        refreshVerse(false);
    }
  }, []);

  return (
    <div className="relative w-full h-20 bg-[#101012] border border-white/5 rounded-2xl overflow-hidden flex items-center justify-center shadow-xl group">
      
      {/* === BACKGROUND: Monochrome Forest Silhouette === */}
      {/* Subtle Repeating Forest Pattern */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-full opacity-[0.05] pointer-events-none"
        style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='100' viewBox='0 0 200 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20,100 L40,40 L60,100 M60,100 L80,20 L100,100 M100,100 L120,50 L140,100 M140,100 L160,30 L180,100' fill='none' stroke='%23ffffff' stroke-width='2' stroke-linejoin='round' /%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat-x',
            backgroundPosition: 'bottom center',
            backgroundSize: '300px 100%'
        }}
      ></div>
      
      {/* Additional Noise Texture */}
      <div className="absolute inset-0 opacity-[0.03]" 
           style={{
             backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
           }}>
      </div>

      {/* === CLASSICAL CORNERS (Monochrome Flourishes) === */}
      <div className="absolute inset-0 pointer-events-none opacity-10">
          {/* Top Left */}
          <svg className="absolute top-2 left-2 w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M2 10V2H10" strokeWidth="1" />
              <path d="M2 2L8 8" strokeWidth="0.5" />
          </svg>
          {/* Top Right */}
          <svg className="absolute top-2 right-2 w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M22 10V2H14" strokeWidth="1" />
              <path d="M22 2L16 8" strokeWidth="0.5" />
          </svg>
           {/* Bottom Left */}
           <svg className="absolute bottom-2 left-2 w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M2 14V22H10" strokeWidth="1" />
              <path d="M2 22L8 16" strokeWidth="0.5" />
          </svg>
          {/* Bottom Right */}
          <svg className="absolute bottom-2 right-2 w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M22 14V22H14" strokeWidth="1" />
              <path d="M22 22L16 16" strokeWidth="0.5" />
          </svg>
      </div>

      {/* === TITLE HEADER === */}
      <div className="absolute top-1.5 left-0 right-0 flex justify-center pointer-events-none">
          <span className="text-[9px] font-serif tracking-[0.3em] text-zinc-600 uppercase">
              松鼠诗社 · Squirrel Poetry Society
          </span>
      </div>

      {/* === POETRY CONTENT === */}
      <div className={`relative z-10 text-center max-w-2xl px-12 transition-all duration-700 ease-in-out ${isAnimating ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
        <p className="text-xs md:text-sm leading-relaxed tracking-wide select-text whitespace-pre-line" 
           style={{ 
             fontFamily: '"Georgia", "Times New Roman", serif',
             color: '#71717a'
           }}>
          <span className="text-[#3b82f6] opacity-80">“</span>
          {verse || "正在聆听森林的低语..."}
          <span className="text-[#3b82f6] opacity-80">”</span>
        </p>
      </div>

      {/* === RIGHT TRIGGER: Classical Imprint/Stamp === */}
      <div className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2">
         <button 
           onClick={() => refreshVerse(true)}
           className="group relative w-12 h-12 flex items-center justify-center opacity-60 hover:opacity-100 transition-all duration-500"
           title="重逢新诗 (Refresh)"
         >
            {/* The Stamp Outer Ring (Imperfect Circle) */}
            <svg viewBox="0 0 100 100" className="w-full h-full text-zinc-700 group-hover:text-zinc-400 transition-colors animate-[spin_10s_linear_infinite_paused] group-hover:animate-none">
                <path id="curve" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" fill="transparent"/>
                <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="1.5" fill="none" strokeDasharray="4 2" />
                <circle cx="50" cy="50" r="34" stroke="currentColor" strokeWidth="0.5" fill="none" />
            </svg>
            
            {/* The Imprint Icon (Leaf/Quill) */}
            <div className="absolute inset-0 flex items-center justify-center text-zinc-600 group-hover:text-zinc-300 transition-colors transform group-hover:scale-110 group-active:scale-95 duration-300">
               {/* Classical Leaf Icon */}
               <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                 <path d="M12 2C7.5 2 4 6.5 4 12C4 17.5 7.5 22 12 22C16.5 22 20 17.5 20 12C20 6.5 16.5 2 12 2ZM12 20C9 20 7 16.5 7 12C7 7.5 9 4 12 4C15 4 17 7.5 17 12C17 16.5 15 20 12 20Z" opacity="0.2"/>
                 <path d="M12 22C12 22 16 16 16 10C16 6 14 4 12 4C10 4 8 6 8 10C8 16 12 22 12 22Z" />
               </svg>
            </div>
         </button>
      </div>

    </div>
  );
};